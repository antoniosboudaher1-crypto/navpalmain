// /// <reference types="vite/client" />
// Types reference commented out to prevent build error in environments where vite is not installed.
