import React from 'react';
import { Place } from '../../types';
import { Navigation, Star, MapPin, Share2, Clock, TriangleAlert } from 'lucide-react';
import GlassCard from '../UI/GlassCard';

interface LocationCardProps {
  place: Place;
  onClose: () => void;
  onNavigate?: () => void;
  onReport?: () => void;
  onReportAtLocation?: () => void;
}

const LocationCard: React.FC<LocationCardProps> = ({ place, onClose, onNavigate, onReport, onReportAtLocation }) => {
  return (
    <GlassCard className="p-6 animate-slide-up shadow-2xl border-white/10">
      <div className="flex justify-between items-start mb-4">
        <h2 className="text-2xl font-bold text-white">{place.name}</h2>
        <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">&times;</button>
      </div>

      <div className="flex items-center gap-2 mb-4 text-yellow-400">
        <Star className="w-5 h-5 fill-current" />
        <span className="font-bold">{place.rating || "4.8"}</span>
        <span className="text-slate-400 text-sm">({place.userRatingsTotal || 120} reviews)</span>
      </div>

      <div className="space-y-4 text-slate-300">
        <div className="flex items-start gap-3">
          <MapPin className="w-5 h-5 text-purple-400 shrink-0 mt-1" />
          <p className="text-sm leading-relaxed">{place.address}</p>
        </div>
        
        <div className="flex items-center gap-3">
          <Clock className="w-5 h-5 text-purple-400 shrink-0" />
          <p className="text-sm text-green-400">Open Now <span className="text-slate-400">• Closes 10 PM</span></p>
        </div>
      </div>

      <div className="mt-8 grid grid-cols-2 gap-3">
        <button 
          onClick={onNavigate}
          className="col-span-2 flex items-center justify-center gap-2 bg-purple-600 hover:bg-purple-500 text-white py-3 rounded-xl font-bold transition-all duration-200 active:scale-95 shadow-lg shadow-purple-900/30"
        >
          <Navigation className="w-5 h-5" />
          Go Now
        </button>
        
        {onReportAtLocation ? (
          <>
             <button className="flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white py-3 rounded-xl font-bold transition-all duration-200 active:scale-95">
              <Share2 className="w-5 h-5" />
              Share
            </button>
             <button 
               onClick={onReportAtLocation}
               className="flex items-center justify-center gap-2 bg-orange-500/10 hover:bg-orange-500/20 text-orange-400 border border-orange-500/20 py-3 rounded-xl font-bold transition-all duration-200 active:scale-95"
             >
               <TriangleAlert className="w-5 h-5" />
               Report
             </button>
          </>
        ) : (
           <button className="col-span-2 flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white py-3 rounded-xl font-bold transition-all duration-200 active:scale-95">
            <Share2 className="w-5 h-5" />
            Share Location
          </button>
        )}
      </div>
    </GlassCard>
  );
};

export default LocationCard;