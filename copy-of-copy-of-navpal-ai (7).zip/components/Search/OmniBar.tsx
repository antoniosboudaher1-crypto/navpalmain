
import React, { useState, useRef } from 'react';
import { Search, Mic, Navigation, Loader2, Send, MicOff, AudioLines, User as UserIcon } from 'lucide-react';
import GlassCard from '../UI/GlassCard';

interface OmniBarProps {
  onSearch: (query: string) => void;
  isLoading: boolean;
  isListening: boolean;
  onMicClick: () => void;
  onProfileClick?: () => void;
  userAvatar?: string;
}

const OmniBar: React.FC<OmniBarProps> = ({ 
  onSearch, 
  isLoading, 
  isListening, 
  onMicClick,
  onProfileClick,
  userAvatar 
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim() && !isLoading) {
      onSearch(query);
      // Note: We DO NOT clear the query here. 
      // In a map app, the search term usually stays visible so the user knows what they are looking at.
      inputRef.current?.blur(); // Dismiss keyboard/focus
    }
  };

  return (
    <GlassCard className="relative z-20 w-full max-w-2xl mx-auto mt-4 p-2 transition-all duration-300">
      <form onSubmit={handleSubmit} className="flex items-center gap-3">
        
        {/* Left Icon / Profile Toggle */}
        {onProfileClick ? (
          <button 
            type="button"
            onClick={onProfileClick}
            className="relative group shrink-0"
          >
             <div className={`w-10 h-10 rounded-2xl overflow-hidden border transition-colors ${isListening ? 'border-red-500/50' : 'border-white/10 group-hover:border-purple-500/50'}`}>
               {userAvatar ? (
                 <img src={userAvatar} alt="Profile" className="w-full h-full object-cover" />
               ) : (
                 <div className="w-full h-full bg-slate-800 flex items-center justify-center">
                    <UserIcon className="w-5 h-5 text-slate-400" />
                 </div>
               )}
             </div>
             {/* Status Indicator */}
             <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-slate-900 ${isLoading ? 'bg-yellow-400 animate-pulse' : isListening ? 'bg-red-500 animate-pulse' : 'bg-green-500'}`}></div>
          </button>
        ) : (
           <div className={`p-3 rounded-2xl transition-colors duration-500 ${isListening ? 'bg-red-500/20 text-red-400' : 'bg-purple-600/20 text-purple-300'}`}>
            {isLoading ? (
              <Loader2 className="w-6 h-6 animate-spin" />
            ) : isListening ? (
              <AudioLines className="w-6 h-6 animate-pulse" />
            ) : (
              <Navigation className="w-6 h-6" />
            )}
          </div>
        )}
        
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={isListening ? "Listening (Live)..." : "Search maps..."}
          className="flex-1 bg-transparent border-none outline-none text-lg font-medium text-white placeholder-slate-400 min-w-0"
        />

        <div className="flex items-center gap-2 pr-2 shrink-0">
          {query.length > 0 ? (
            <button 
              type="submit"
              className="p-2 rounded-full bg-purple-600 text-white hover:bg-purple-500 transition-colors shadow-lg shadow-purple-900/20"
            >
              <Send className="w-5 h-5" />
            </button>
          ) : (
            <button 
              type="button" 
              onClick={onMicClick}
              className={`p-2 rounded-full transition-all duration-300 ${
                isListening 
                  ? 'bg-red-500 text-white animate-pulse shadow-[0_0_20px_rgba(239,68,68,0.6)] scale-110' 
                  : 'hover:bg-white/5 text-slate-400 hover:text-white'
              }`}
              title={isListening ? "Stop Live Conversation" : "Start Live Conversation"}
            >
              {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>
          )}
        </div>
      </form>
    </GlassCard>
  );
};

export default OmniBar;
